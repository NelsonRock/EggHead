angular.module('categories.bookmarks.edit', []);
