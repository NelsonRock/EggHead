angular.module('categories.bookmarks.create', []);
