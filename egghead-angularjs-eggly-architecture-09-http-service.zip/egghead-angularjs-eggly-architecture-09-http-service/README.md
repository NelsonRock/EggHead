eggly
=====

AngularJS bookmark manager.
